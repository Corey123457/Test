# lab05
- Link to create your repository: https://classroom.github.com/a/Vni6Ius2
- Due date: Oct. 28, 2025
- [Lab manual](lab05-format-string.pdf)
- Copy the respective labsetup folder for your architecture
- Final contents of your repository:
  - `lab05-report.pdf`
  - your source code files
---
## Provided code
The required code for this lab has been provided in a folder corresponding to your architecture:
- [Code folder for Intel/AMD (x64)](./labsetup-x64/)
- [Code folder for Apple (ARM64)](./labsetup-arm64/)

Note that you can ignore the instruction in the manual about unzipping the code folder, as the folder has already been unpacked here.

## Hint on Address Placment for 64-bit processes
In the 64-bit architecture, addresses can contain leading zero bytes (e.g., `0x000077FFAABBCCDD`). If you place such an address at the beginning of your payload (which will be interpreted as the format string) the first zero byte encountered will act as the NULL terminator for the format string. As a result, `printf()` will stop processing the buffer earlier than intended.

Instead of placing the addresses at the beginning of the buffer, place them after your format string (i.e., after the specifiers you need to be processed). Also, rather than using `%hn` as in the 32-bit attack, use the indexed argument form `%m$hn`, which tells `printf()` to use its `m`-th argument (rather than the next sequential argument) as the address for writing the number of characters. The `m$` syntax can be applied to any other format specifier in the same way.

## Bash prompt (reminder)
Make sure you have already set up your VM's bash prompt as instructed in [lab01](https://github.com/ualbany-csi524-f25/lab01). Your prompts must be clearly visible in all screenshots that you include in your reports.

## Report instructions
Create a single PDF file report:
- Number tasks according to the lab manual.
- Take screenshots of the input/outputs for each step and embed them in your report.
- Write at least a sentence before each screenshot to describe what you performed in a given screenshot. Simply including screenshots wihthout proper description receives no credit.
- Write your answers and describe/explain your observations as requested in the lab manual. Note that you need to carefully read each task description as questions are not always explicitly marked in the manual.

## Source code instructions
- You must include all source files that you used in the lab (even those given to you in the manual).
- Do not include your compiled files.
- Naming your source code files:
  - If the manual indicates a source file name, simply use that name.
  - Otherwise, name your file according to the task numbers: e.g., `task3.c`, `task4a.c`
- Note that including the source codes without proper discussion of your work in the report receives no credit.
